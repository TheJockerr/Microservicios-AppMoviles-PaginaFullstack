package com.example.users_service.exception;


public class UsuarioException extends RuntimeException {
    public UsuarioException(String message) {
        super(message);
    }
}

